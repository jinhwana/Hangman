

public class Hangman{

     public static void main(String[] args) {
          HangmanGame hg = new HangmanGame();
          hg.game();
     }
}

